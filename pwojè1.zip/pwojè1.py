print('---------------------Pwojè1---------------------')
N=int (input('ki kantite nòt ou vle rantre: '))
list_nòt=[]
print(list_nòt)
for i in range(N):
    n= int(input('rantre nòt yo: '))
    list_nòt.append(n)
moy=sum(list_nòt)/N
print(moy)
if(moy>90):
    print('A')
elif(moy>=80 and moy<90):
    print('B')
elif(moy>=70 and moy<80):
    print('C')
elif(moy>=60 and moy<70):
    print('D')
elif(moy<60):
    print('F')
    

 